ENT.Base = "base_gmodentity"
ENT.Type = "anim"

ENT.PrintName = "Карта"
ENT.Category = "AURORA | Утилиты"

ENT.Spawnable = true
ENT.AdminOnly = false