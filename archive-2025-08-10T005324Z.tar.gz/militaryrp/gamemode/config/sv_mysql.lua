MySQLite.initialize(
    {
        EnableMySQL      = true,
        Host             = '45.11.16.73',
        Username         = 'u2102_dpNRZgwHHO',
        Password         = 'jL@!5Aa75YYnr^EkjNo9hsiT',
        Database_name    = 's2102_biohazard',
        Database_port    = 3306,
        Preferred_module = 'mysqloo',
    }
) 