-- core
AddCSLuaFile('core/cl_core.lua')
include('core/sv_core.lua')

-- UI utility
AddCSLuaFile('ui/cl_util.lua')

-- admin tab
AddCSLuaFile('tabs/cl_gmap_admin.lua')

-- UI components
AddCSLuaFile('ui/cl_frame.lua')
AddCSLuaFile('ui/cl_info.lua')
AddCSLuaFile('ui/cl_planet.lua')
AddCSLuaFile('ui/cl_wrap_text.lua')
AddCSLuaFile('ui/cl_canvas.lua')
AddCSLuaFile('ui/cl_checkbox.lua')
AddCSLuaFile('ui/cl_entry.lua')
AddCSLuaFile('ui/cl_combobox.lua')
AddCSLuaFile('ui/cl_button.lua')
AddCSLuaFile('ui/cl_horiz_scroll.lua')

