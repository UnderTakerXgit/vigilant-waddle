NextRP.Config.Admins = {
	["superadmin"] = true,
	["gadmin"] = true,
	["sadmin"] = true,
	["stadmin"] = true,
	["admin"] = true,
	["sthelper"] = true,
	["helper"] = true,
	["trainee"] = true,
	["givent"] = true,
	["stivent"] = true,
	["ivent"] = true
}