AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")

-- Все наши настройки
include("shared.lua")