ENT.Base      = "base_ai"
ENT.Type      = "ai"
ENT.PrintName = 'Спавнер техники'
ENT.Author = 'Kot'
ENT.Contact = ''
ENT.Purpose = ''
ENT.Instructions = ''
ENT.Spawnable = true
ENT.AdminSpawnable = false
ENT.Category = '!Rephyx.tech | Утилиты'
ENT.Editable = false
ENT.Carry = false 

ENT.RenderGroup = RENDERGROUP_TRANSLUCENT