
surface.CreateFont( 'font_sans_3d2d_large', { font = 'Open Sans', size = 128, weight = 500, extended = true })
surface.CreateFont( 'font_sans_3d2d_small', { font = 'Open Sans', size = 72, weight = 500, extended = true })

surface.CreateFont( 'font_sans_56', { font = 'Open Sans', size = 56, weight = 500, extended = true })
surface.CreateFont( 'font_sans_72', { font = 'Open Sans', size = 72, weight = 500, extended = true })
surface.CreateFont( 'font_sans_35', { font = 'Open Sans', size = 35, weight = 500, extended = true })
surface.CreateFont( 'font_sans_32', { font = 'Open Sans', size = 32, weight = 500, extended = true })
surface.CreateFont( 'font_sans_26', { font = 'Open Sans', size = 26, weight = 500, extended = true })
surface.CreateFont( 'font_sans_24', { font = 'Open Sans', size = 24, weight = 500, extended = true })
surface.CreateFont( 'font_sans_21', { font = 'Open Sans', size = 21, weight = 500, extended = true })
surface.CreateFont( 'font_sans_18', { font = 'Open Sans', size = 18, weight = 500, extended = true })
surface.CreateFont( 'font_sans_16', { font = 'Open Sans', size = 16, weight = 500, extended = true }) 
surface.CreateFont( 'font_sans_12', { font = 'Open Sans', size = 12, weight = 500, extended = true }) 
